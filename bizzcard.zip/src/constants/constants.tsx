export enum ProfileImgShape {
    SQUARE = "SQUARE",
    CIRCLE = "CIRCLE",
}
export enum BgColor {
    MAIN = "MAIN",
    BLUE = "BLUE",
}
export enum MainColor {
    BLACK = "BLACK",
    GREEN = "GREEN",
    WHITE = "WHITE"
}
